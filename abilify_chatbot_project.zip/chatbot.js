let lastMessage = "";

function sendMessage() {
    const input = document.getElementById("userInput");
    const message = input.value;

    if (message.trim() === "") return;

    addMessage("You: " + message);

    let reply = getBotResponse(message);

    addMessage("Bot: " + reply);
    speak(reply);

    lastMessage = reply;
    input.value = "";
}

function addMessage(text) {
    const chatbox = document.getElementById("chatbox");
    const msg = document.createElement("p");
    msg.innerText = text;
    chatbox.appendChild(msg);
}

function getBotResponse(input) {
    input = input.toLowerCase();
    if (input.includes("hello")) return "Hello! How can I help you?";
    if (input.includes("help")) return "I am here to support you.";
    return "I understand. Tell me more.";
}

function speak(text) {
    const speech = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(speech);
}

function speakLastMessage() {
    speak(lastMessage);
}

function startListening() {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.start();

    recognition.onresult = function(event) {
        const text = event.results[0][0].transcript;
        document.getElementById("userInput").value = text;
        sendMessage();
    };
}

function startCamera() {
    const video = document.getElementById('camera');
    video.style.display = "block";

    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            video.srcObject = stream;
        })
        .catch(err => alert("Camera access denied"));
}
